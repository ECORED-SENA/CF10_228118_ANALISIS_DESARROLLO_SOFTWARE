function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6m3F9AxBMXO":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

